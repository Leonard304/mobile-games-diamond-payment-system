/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minershop;

/**
 *
 * @author Leonard Balaba
 */
public class TempClass {
    static String email;
    static String game;
    static String userID;
    static String server;
    static String item;
    static String payment;
    static double price;
    TempClass(String email, String game, String userID, String server, String item, String payment, double price){
        this.email = email;
        this.game = game;
        this.userID = userID;
        this.server = server;
        this.item = item;
        this.payment = payment;
        this.price = price;
    }
    TempClass(String email, String game, String userID, String item, String payment, double price){
        this.email = email;
        this.game = game;
        this.userID = userID;
        this.item = item;
        this.payment = payment;
        this.price = price;
    }
    
}
