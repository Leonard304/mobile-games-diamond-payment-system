/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minershop;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Leonard Balaba
 */
public class Database {
    
    static final String USER ="jdbc:mysql://localhost:3306/minershop";
    static final String DB_URL="root";
    static final String PASS="";
    
    public static void main(String[] args){
        try{
            Connection conn = DriverManager.getConnection(USER,DB_URL,PASS);
            System.out.println("Connection Successfully");
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }

    }
    
    public static void deleteData(int cus_id){
        try{
            String query = "DELETE FROM customers WHERE Customer_ID = ?";
            Connection conn = DriverManager.getConnection(USER,DB_URL,PASS);
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, cus_id);
            int rowsAffected = pstmt.executeUpdate();
            if(rowsAffected > 0){
                JOptionPane.showMessageDialog(new Admin(new Welcome(),true), "Data Deleted");
                return;
            }
            conn.close();
            pstmt.close();
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(new Admin(new Welcome(),true), ex.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    public static void normalGames(String email, 
            String games, 
            String userID, 
            String item, 
            String payment, 
            double price, 
            String phone){
        try{
            Connection conn = DriverManager.getConnection(USER,DB_URL,PASS);            
            String query = "INSERT INTO customers(Email,Game,User_ID,Item,Payment,Price,Phone) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, email);
            pstmt.setString(2, games);
            pstmt.setString(3, userID);
            pstmt.setString(4, item);
            pstmt.setString(5, payment);
            pstmt.setDouble(6, price);
            pstmt.setString(7, phone);
            int rowsAffected = pstmt.executeUpdate();
            if(rowsAffected > 0){
                JOptionPane.showMessageDialog(new PaymentConfirm(), "Payment Recharge Successful");
                return;
            }
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(new PaymentConfirm(), e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    
    public static void mmorpgGames(String email, 
            String games, 
            String userID, 
            String server,
            String item, 
            String payment, 
            double price, 
            String phone){
        try{
            Connection conn = DriverManager.getConnection(USER,DB_URL,PASS);            
            String query = "INSERT INTO customers(Email,Game,User_ID,Game_Server,Item,Payment,Price,Phone) VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, email);
            pstmt.setString(2, games);
            pstmt.setString(3, userID);
            pstmt.setString(4, server);
            pstmt.setString(5, item);
            pstmt.setString(6, payment);
            pstmt.setDouble(7, price);
            pstmt.setString(8, phone);
            int rowsAffected = pstmt.executeUpdate();
            if(rowsAffected > 0){
                JOptionPane.showMessageDialog(new PaymentConfirm(), "Payment Recharge Successful");
                return;
            }
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(new PaymentConfirm(), e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
        
}
